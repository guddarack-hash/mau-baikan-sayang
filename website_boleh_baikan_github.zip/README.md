# Boleh Baikan? 🤍

Website satu halaman untuk dibuka lewat HP maupun komputer. Tidak perlu install aplikasi atau framework.

## Cara upload ke GitHub

1. Login ke https://github.com
2. Klik tombol **New repository**.
3. Isi nama repository, misalnya `boleh-baikan`.
4. Pilih **Public**, lalu klik **Create repository**.
5. Klik **Add file → Upload files**.
6. Upload file `index.html` dari folder ini.
7. Klik **Commit changes**.

## Cara mengaktifkan GitHub Pages

1. Buka repository yang baru dibuat.
2. Masuk ke **Settings → Pages**.
3. Pada bagian **Build and deployment**, pilih **Deploy from a branch**.
4. Pilih branch **main** dan folder **/(root)**.
5. Klik **Save**.
6. Tunggu proses publikasi selesai. Link website akan muncul di halaman Pages, biasanya berbentuk:
   `https://USERNAME.github.io/boleh-baikan/`

Ganti `USERNAME` dengan username GitHub kamu. Link tersebut bisa dibuka dan dikirim lewat WhatsApp.

## Tentang lagu

Tombol lagu membuka hasil pencarian YouTube untuk **LANY — cause you have to**. Website ini tidak menyimpan atau meng-host file audio lagu.
